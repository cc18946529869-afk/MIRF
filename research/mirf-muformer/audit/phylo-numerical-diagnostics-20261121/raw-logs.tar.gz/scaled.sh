#!/usr/bin/env bash
set -eu
work=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121
stage="$work/.work/trials"
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
/usr/bin/time -v -o "$stage/short-10000-scaled-4.time" python3 -m perf.check_f81_numerical_diagnostics --library "$stage/pruning.so" --boundary "$stage/boundary.so" --prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --rows 10000 --threads 4 --probe --scaled-probe --trace "$stage/short-10000-scaled-4.jsonl" > "$stage/short-10000-scaled-4.json" 2> "$stage/short-10000-scaled-4.stderr"
date -Iseconds > "$stage/scaled-finished.txt"
