from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import tarfile

work=Path(".work")
run=work/"trials"
dst=Path("research/mirf-muformer/audit/phylo-numerical-diagnostics-20261121")
dst.mkdir(parents=True,exist_ok=True)
assert (run/"finished.txt").is_file() and (run/"scaled-finished.txt").is_file()
def read(name):
    return json.loads((run/f"{name}.json").read_text())
def ledger(name):
    return [json.loads(line) for line in (run/f"{name}.jsonl").read_text().splitlines()]
def strip(trace):
    return [{k:v for k,v in row.items() if k!="seconds"} for row in trace]
cases={name:read(name) for name in ("short-1000-4","short-1000-1","short-10000-4")}
traces={name:ledger(name) for name in cases}
equal=strip(traces["short-1000-4"])==strip(traces["short-1000-1"])
assert equal
scaled_name="short-10000-scaled-4"
scaled=read(scaled_name)
assert strip(traces["short-10000-4"])==strip(ledger(scaled_name))
assert scaled["trace_audit"]["accepted_monotone"]
old=json.loads(Path("research/mirf-muformer/audit/phylo-observed-bridge-20261121/bridge-results.json").read_text())
line_audit={}
for name,rows in traces.items():
    size=str(cases[name]["sample_size"])
    earlier=next(x for x in old["trials"][size] if x["start"]=="short")
    for field in ("reference_profile_sha256","alignment_weights_sha256","indices_sha256","topology_sha256"):
        assert cases[name][field]==earlier[field],field
    searches={item["search"]:item for item in rows if item["event"]=="line_search"}
    attempts=[item for item in rows if item["event"]=="line_trial"]
    for x in attempts:
        if x["outcome"] in ("accepted","armijo_rejected"):
            assert x["trial_value"]-x["armijo_rhs"]==x["armijo_gap"]
            assert (x["trial_value"]<=x["armijo_rhs"])==(x["outcome"]=="accepted")
            assert x["projected_directional_derivative"]<0
    fit=cases[name]["search"]
    assert fit["maxeval"]==260 and fit["maxiter"]==150 and fit["gtol_per_site"]==1e-5
    assert cases[name]["trace_audit"]["accepted_monotone"]
    tail=[]
    for key in sorted(searches)[-2:]:
        if searches[key]["iteration"]!=fit["iterations"]: continue
        own=[x for x in attempts if x["search"]==key]
        finite=[x for x in own if "armijo_gap" in x]
        tail.append({"method":searches[key]["method"],
                     "direction_inf":searches[key]["direction_inf"],
                     "directional_derivative":searches[key]["directional_derivative"],
                     "attempts":len(own),"outcomes":dict(Counter(x["outcome"] for x in own)),
                     "negative_rhs_attempts":sum(x["armijo_rhs"]<0 for x in finite),
                     "last_displacement_inf":own[-1].get("displacement_inf") if own else None,
                     "min_tried_step":min((x["step"] for x in own),default=None),
                     "last_armijo_gap":finite[-1]["armijo_gap"] if finite else None,
                     "last_lhs":finite[-1]["trial_value"] if finite else None,
                     "last_rhs":finite[-1]["armijo_rhs"] if finite else None})
    candidates=[(m["direction"],x) for result in cases[name]["terminal_diagnostics"]
                 for m in result["rays"] for x in m["probes_following_same_ray"]
                 if "independent_armijo_gap" in x and x["independent_armijo_gap"] <= 0]
    line_audit[name]={"outcomes":dict(Counter(x["outcome"] for x in attempts)),
                      "terminal_searches":tail,"independently_passing_diagnostic_trials":candidates}
    checks=cases[name]["start_thread_checks"]+cases[name]["terminal_thread_checks"]
    assert all(x["bitwise_equal"] and x["threads"]==[1,2,4] for x in checks)

with tarfile.open(dst/"raw-logs.tar.gz","w:gz") as archive:
    logs=[p for p in run.rglob("*") if p.is_file() and p.suffix in (".json",".jsonl",".time",".stderr",".txt")]
    logs += [work/"execute.stdout",work/"execute.stderr",work/"environment.txt",work/"execute.sh",work/"scaled.sh",work/"scaled.stdout",work/"scaled.stderr",work/"summarize.py"]
    for path in sorted(set(logs)):
        blob=path.read_bytes()
        info=tarfile.TarInfo(str(path.relative_to(work)))
        info.size=len(blob)
        info.mtime=0
        archive.addfile(info,io.BytesIO(blob))
with (dst/"raw-logs.tar.gz").open("rb") as f:
    sha=hashlib.file_digest(f,"sha256").hexdigest()
results={"cases":cases,"line_search_audit":line_audit,"1000_complete_search_trace_equal_1_vs_4_excluding_timings":equal,
         "scale_aware_terminal_replay":{"case":scaled,"complete_search_trace_equal_excluding_timings":True},
         "oracle":read("decimal-oracle"),"raw_logs_sha256":sha}
(dst/"results.json").write_text(json.dumps(results,indent=2,allow_nan=False)+"\n")
for name,case in cases.items():
    print(name,case['search']['status'],case['search']['iterations'],case['search']['solver_likelihood_gradient_evaluations'],
          case['search']['terminal_projected_gradient_per_site'],case['search']['infeasible_trials'])
    print(json.dumps({k:v for k,v in line_audit[name].items() if k!="independently_passing_diagnostic_trials"}))
    for t in case["terminal_diagnostics"]:
        print(t["normal_vs_rerooted_log_gradient_max_abs"],t["dominant_projected_coordinate_length"],
              t["one_sided_dominant_coordinate_probes"])
