#!/usr/bin/env bash
set -eo pipefail
stage=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
mkdir "$stage" "$stage/small-fit-traces"
cd /data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/research/mirf-muformer/dcr
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
run() {
  local label=$1 sec=$2
  shift 2
  /usr/bin/time -v -o "$stage/$label.time" timeout --signal=TERM --kill-after=10s "$sec" "$@" > "$stage/$label.json" 2> "$stage/$label.stderr"
  printf '%s %s complete\n' "$(date -Iseconds)" "$label"
}
pruning="$stage/pruning.so"
boundary="$stage/boundary.so"
run decimal-oracle 180 python3 -m perf.check_f81_numerical_diagnostics --library "$pruning" --boundary "$boundary" --check
run pruning-regression 180 python3 -m perf.check_f81_pruning --check --library "$stage/pruning-regression.so"
run optimizer-regression 180 python3 -m perf.check_f81_optimization --check --library "$stage/optimizer-regression.so" --logs "$stage/small-fit-traces"
run boundary-regression 300 python3 -m perf.check_f81_zero_boundary --pruning-library "$pruning" --boundary-library "$boundary" --random-cases 2400
common=(--library "$pruning" --boundary "$boundary" --prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate /data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json)
run short-1000-4 900 python3 -m perf.check_f81_numerical_diagnostics "${common[@]}" --rows 1000 --threads 4 --snapshot --probe --trace "$stage/short-1000-4.jsonl"
run short-1000-1 900 python3 -m perf.check_f81_numerical_diagnostics "${common[@]}" --rows 1000 --threads 1 --trace "$stage/short-1000-1.jsonl"
run short-10000-4 1800 python3 -m perf.check_f81_numerical_diagnostics "${common[@]}" --rows 10000 --threads 4 --snapshot --probe --trace "$stage/short-10000-4.jsonl"
date -Iseconds > "$stage/finished.txt"
