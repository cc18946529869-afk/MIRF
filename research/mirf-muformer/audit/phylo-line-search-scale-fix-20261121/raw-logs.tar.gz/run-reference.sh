#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
study="$work/.work/run"
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library /data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials/pruning.so --reference "$study/f81-split-gradient.so")
run() {
  local name=$1
  shift
  /usr/bin/time -v -o "$study/$name.time" python3 -m perf.check_f81_split_gradient "${common[@]}" "$@" > "$study/$name.json" 2> "$study/$name.stderr"
  printf '%s %s complete\n' "$(date -Iseconds)" "$name"
}
run oracle-check --check
for id in archived scaled-10000; do
    until test -s "$study/$id.json"; do
        kill -0 "$(cat "$work/.work/run/scale.pid")"
        sleep 4
    done
    run "precision-$id" --checkpoint "$study/$id.npy"
done
