#!/usr/bin/env bash
set -euo pipefail
home_dir=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121
study="$home_dir/.work/run"
cd "$home_dir/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
old=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$home_dir/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$old/pruning.so" --boundary "$old/boundary.so")
run() {
  local name=$1
  shift
  /usr/bin/time -v -o "$study/$name.time" python3 -m perf.check_f81_line_search_scale "$@" > "$study/$name.json" 2> "$study/$name.stderr"
  printf '%s %s complete\n' "$(date -Iseconds)" "$name"
}
run initializer --check
run archived "${common[@]}" --rows 10000 --trace "$study/archived.jsonl" --checkpoint "$study/archived.npy" --baseline-replay "$old/short-10000-4.jsonl"
run scaled-10000 "${common[@]}" --rows 10000 --trace "$study/scaled-10000.jsonl" --checkpoint "$study/scaled-10000.npy"
run scaled-1000 "${common[@]}" --rows 1000 --trace "$study/scaled-1000.jsonl" --checkpoint "$study/scaled-1000.npy"
