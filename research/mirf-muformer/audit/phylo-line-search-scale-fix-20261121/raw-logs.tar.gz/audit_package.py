"""Verify the frozen conditions independently from scalar logs and package evidence."""
from argparse import ArgumentParser
from collections import Counter
from decimal import Decimal, localcontext
import hashlib
import io
import json
from pathlib import Path
import tarfile

work = Path(".work")
run = work / "run"
out = Path("research/mirf-muformer/audit/phylo-line-search-scale-fix-20261121")
prior = Path("research/mirf-muformer/audit/phylo-numerical-diagnostics-20261121/results.json")
out.mkdir(parents=True, exist_ok=True)
parser = ArgumentParser(description=__doc__)
parser.add_argument("--previous-logs", type=Path, required=True)
args = parser.parse_args()


def read(name):
    return json.loads((run / f"{name}.json").read_text())


def rows(name):
    return [json.loads(line) for line in (run / f"{name}.jsonl").read_text().splitlines()]


def verify(case, name):
    events = rows(name)
    fit = case["search"]
    values = {e["call"]: -e["log_likelihood"] for e in events
              if e["event"] == "evaluation" and e["finite"]}
    accepted = [values[e["calls"]] for e in events if e["event"] == "accepted"]
    assert -fit["initial_log_likelihood"] >= accepted[0]
    assert all(a >= b for a, b in zip(accepted, accepted[1:]))
    assert case["trace"]["accepted_monotone"]
    assert len(accepted) == fit["iterations"] <= fit["maxiter"] == 150
    assert len(values) == fit["solver_likelihood_gradient_evaluations"] <= fit["maxeval"] == 260
    assert fit["gtol_per_site"] == 1e-5 and fit["infeasible_trials"] == 0
    assert fit["restricted_curvature_to_free_coordinates"]
    assert case["independent_terminal"]["abs_gate"] == 1e-8
    attempts = [e for e in events if e["event"] == "line_trial"]
    assert max(e["attempt"] for e in attempts) <= 24
    counts = Counter(e["outcome"] for e in attempts)
    assert counts["accepted"] == len(accepted)
    for attempt in attempts:
        if attempt["outcome"] in {"accepted", "armijo_rejected", "armijo_below_objective_bound"}:
            q = attempt["projected_directional_derivative"]
            rhs = attempt["current_value"] + 0.0001 * q
            assert rhs == attempt["armijo_rhs"] and q < 0
            if attempt["outcome"] == "armijo_below_objective_bound":
                assert rhs < 0
            else:
                assert (attempt["trial_value"] <= rhs) == (attempt["outcome"] == "accepted")
                if name != "archived":
                    assert rhs >= 0
    scaling = {e["search"]: e for e in events if e["event"] == "projected_scale"}
    for event in scaling.values():
        assert 0 <= event["scaled_step"] <= event["unscaled_step"]
    for attempt in attempts:
        if attempt["attempt"] != 1 or not scaling:
            continue
        assert attempt["step"] == scaling[attempt["search"]]["scaled_step"]
        q = attempt.get("projected_directional_derivative")
        if q is not None and q < 0 and attempt["current_value"] > 0:
            assert -0.0001 * q <= 0.01 * attempt["current_value"]
    return {"trial_outcomes": dict(counts), "scaled_searches": sum(
        e["scaled_step"] < e["unscaled_step"] for e in scaling.values()),
        "accepted_objective_monotonic": True, "verified_trial_acceptance": True}


baseline = json.loads(prior.read_text())["cases"]
cases = {name: read(name) for name in ("archived", "scaled-10000", "scaled-1000")}
verification = {}
for name, case in cases.items():
    verification[name] = verify(case, name)
    existing = baseline[f'short-{case["sample_size"]}-4']
    for key in ("alignment_weights_sha256", "indices_sha256", "reference_profile_sha256",
                "topology_sha256", "library_sha256"):
        assert case[key] == existing[key]

old_1000 = [json.loads(line) for line in (args.previous_logs / "short-1000-4.jsonl").read_text().splitlines()]
def numerical_entries(events):
    return [{k: v for k, v in row.items() if k != "seconds"}
            for row in events if row["event"] != "projected_scale"]

assert numerical_entries(old_1000) == numerical_entries(rows("scaled-1000"))
verification["scaled-1000"]["same_numerical_trace_as_previous"] = True
tail = [e for e in rows("scaled-10000") if e.get("outcome") == "accepted"][-100:]
assert len(tail) == 100 and all(e["step"] == 1 and e["attempt"] == 1 for e in tail)
verification["scaled-10000"]["last_100_displacement_inf_range"] = [
    min(e["displacement_inf"] for e in tail), max(e["displacement_inf"] for e in tail)]
old = cases["archived"]
assert old["same_terminal_as_archived_replay"]
assert old["search"]["status"] == "no_finite_armijo_step"
assert len(old["same_terminal_ray_replay"]) == 2
for ray in old["same_terminal_ray_replay"]:
    assert len(ray["trials"]) <= 24
    last = ray["trials"][-1]
    assert last["outcome"] == "accepted" and last["independent_armijo_gap"] < 0

precise = {}
for name in ("archived", "scaled-10000"):
    data = read(f"precision-{name}")
    assert data["checkpoint_sha256"] == cases[name]["checkpoint_sha256"]
    with localcontext() as ctx:
        ctx.prec = 115
        for x in data["coordinates"]:
            ref = Decimal(x["reference_256bit"])
            low = Decimal(x["reference_192bit"])
            assert abs(ref - low) == Decimal(x["reference_pair_abs_difference"])
            rounded = Decimal.from_float(float(ref))
            assert Decimal.from_float(x["nearest_binary64"]) == rounded
            repr_error = rounded - ref
            assert repr_error == Decimal(x["signed_representation_error"])
            for path in x["paths"].values():
                value = Decimal.from_float(path["binary64"])
                assert value - ref == Decimal(path["signed_total_error_to_reference"])
                assert value - rounded == Decimal(path["signed_algorithm_error_to_nearest"])
    precise[name] = data

passed = all(
    cases[k]["search"]["passed"]
    and cases[k]["independent_terminal"]["convergence_passed"]
    and cases[k]["independent_terminal"]["gradient_agreement_passed"]
    for k in ("scaled-10000", "scaled-1000")
)
assert read("initializer")["passed"] and read("oracle-check")["passed"] and read("zero-regression")["passed"]
with tarfile.open(out / "raw-logs.tar.gz", "w:gz") as archive:
    allowed = (".json", ".jsonl", ".stdout", ".stderr", ".time")
    locations = [p for p in run.rglob("*") if p.is_file() and p.suffix in allowed]
    locations += [work / name for name in ("audit_package.py", "environment.txt",
                                            "run-scale.sh", "run-reference.sh")]
    for path in sorted(locations):
        payload = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to(work)))
        info.size = len(payload)
        info.mtime = 0
        archive.addfile(info, io.BytesIO(payload))
digest = hashlib.sha256((out / "raw-logs.tar.gz").read_bytes()).hexdigest()
result = {"passed": passed, "fits": cases, "ledger_verification": verification,
          "selected_high_precision_coordinates": precise, "raw_logs_sha256": digest}
(out / "results.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
for name, case in cases.items():
    fit = case["search"]
    print(name, fit["status"], fit["iterations"], fit["solver_likelihood_gradient_evaluations"],
          fit["terminal_log_likelihood"], fit["terminal_projected_gradient_per_site"],
          case["independent_terminal"]["gradient_max_abs_difference"], verification[name])
print("pass", passed)
