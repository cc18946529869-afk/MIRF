"""Check the two high-precision paths against the anonymous quartet oracle."""
from decimal import Decimal, localcontext
import sys
from pathlib import Path
import json

import numpy as np

from perf.check_f81_edge_conditioning import TangentReference
from perf.check_f81_recoverability import TRUTHS, PATTERNS, engine_for, law
from perf.check_f81_split_gradient import Reference

native, split_library, dual_library = map(Path, sys.argv[1:])
results = []
with localcontext() as ctx:
    ctx.prec = 110
    for label, point in TRUTHS.items():
        mass, first = law(point, 1)
        expected = -np.mean(first/mass[:, None], axis=0)
        old = engine_for(PATTERNS, native, root=4)
        alternate = engine_for(PATTERNS, native, root=5)
        ref = Reference(old, point, split_library)
        dual = TangentReference(alternate, dual_library)
        for bits in (192, 256):
            for edge, score in enumerate(expected):
                a, b = ref.score(edge, bits), dual.score(point, edge, bits)
                assert abs(a-b) <= Decimal("1e-50")
                error = abs(np.longdouble(str(b))-score)
                assert error < 1e-15
                results.append({"truth": label, "bits": bits, "edge": edge, "split_tangent_abs": str(abs(a-b)),
                                "enum_tangent_abs": float(error)})
print(json.dumps({"passed": True, "cases": results}, indent=2))
