"""Audit local trials, reference errors and full-coordinate gate checks."""
from decimal import Decimal, localcontext
import hashlib
import io
import json
from pathlib import Path
import tarfile

work = Path(".work")
logs = work / "run"
out = Path("research/mirf-muformer/audit/phylo-boundary-conditioning-20261121")
out.mkdir(parents=True, exist_ok=True)
gate = Decimal("1e-8")


def audit_local(row):
    assert len(row["trials"]) + 1 == row["evaluations"] <= 96
    length = row["start_length"]
    last = Decimal(0)
    accepted = 0
    for i, trial in enumerate(row.pop("trials"), 2):
        assert trial["evaluation"] == i
        assert trial["length_before"] == length
        assert trial["length_trial"] >= 0
        assert trial["length_trial"] != 0 or row["zero_feasible"]
        q = Decimal(trial["projected_slope"])
        assert q < 0 and Decimal(trial["armijo_rhs"]) == last+Decimal("1e-4")*q
        if trial["accepted"]:
            value = Decimal(trial["objective"])
            assert value <= Decimal(trial["armijo_rhs"]) and value < last
            length, last = trial["length_trial"], value
            accepted += 1
    assert length == row["end_length"] and accepted == row["accepted_updates"]
    assert last == Decimal(row["relative_objective"])
    residual = abs(min(Decimal.from_float(length), Decimal(row["gradient_s"])))
    assert residual == Decimal(row["projected_s"])
    assert (residual <= Decimal("1e-5")) == (row["status"] == "local_projected_gradient")


def audit_reference(precision):
    levels = precision["higher_precision_paths"]
    reference = Decimal(levels["256"]["split"])
    for record in levels.values():
        split, tangent = Decimal(record["split"]), Decimal(record["tangent"])
        assert abs(split-tangent) == Decimal(record["absolute_difference"])
        assert (abs(split-tangent) <= gate) == record["passes_absolute_gate"]
        record["split_abs_to_256bit_reference"] = str(abs(split-reference))
        record["tangent_abs_to_256bit_reference"] = str(abs(tangent-reference))
        record["both_pass_256bit_reference_absolute_gate"] = max(abs(split-reference), abs(tangent-reference)) <= gate
    binary = precision["binary64"]
    nearest = Decimal.from_float(binary["nearest_to_reference"])
    assert abs(nearest-reference) == Decimal(binary["representation_error_abs"])


def audit_experiment(x):
    audit_reference(x["precision_before"])
    audit_reference(x["precision_after"])
    for test in x.get("local_strategies", [x.get("local_trials")]):
        audit_local(test)
    check = (x["independent_mean_objective_change"] < 0
             and x["after_proposal"]["projected_gradient_inf"] < x["before"]["projected_gradient_inf"]
             and x["after_proposal"]["rerooted_projected_gradient_inf"] < x["before"]["rerooted_projected_gradient_inf"]
             and all(k["passes_absolute_gate"] for k in x["precision_after"]["higher_precision_paths"].values()))
    assert x["whole_tree_update_retained"] == check


results = {}
with localcontext() as ctx:
    ctx.prec = 115
    for label in ("short-10000", "warm-10000", "previous-10000"):
        data = json.loads((logs/f"{label}.json").read_text())
        for x in data["isolated_branches"]:
            audit_experiment(x)
        current = data["before"]
        for x in data["retained_chain"]:
            assert current == x["before"]
            audit_experiment(x)
            if x["whole_tree_update_retained"]:
                current = x["after_proposal"]
        assert current == data["after"]
        assert data["after"]["cross_path_gradient_passed"] == (data["after"]["cross_path_gradient_abs"] <= 1e-8)
        results[label] = data

members = [p for p in logs.iterdir() if p.is_file()
           and p.suffix in (".stdout", ".stderr", ".json", ".time")]
members += [work/name for name in ("run-conditioning.sh", "package.py", "environment.txt", "native-check.py")]
with tarfile.open(out/"run-logs.tar.gz", "w:gz") as tar:
    for member in sorted(members):
        data = member.read_bytes()
        info = tarfile.TarInfo(str(member.relative_to(work)))
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
summary = {"cases": results, "unit_and_native_reference_checked": True,
           "raw_trace_sha256": hashlib.sha256((out/"run-logs.tar.gz").read_bytes()).hexdigest()}
(out/"results.json").write_text(json.dumps(summary, indent=2, allow_nan=False)+"\n")
for label, data in results.items():
    print(label, data["before"], data["after"])
    for n, x in enumerate(data["retained_chain"], 1):
        print(n, x["edge"], x["whole_tree_update_retained"],
              x["after_proposal"]["rerooted_projected_gradient_inf"], x["independent_mean_objective_change"])
