#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-boundary-conditioning-20261121
logs="$work/.work/run"
stage2=/data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121
prior=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121/.work/run
comparison=/data/cc233_data/work_dir/MIRF-phylo-optimizer-comparison-20261121/.work/run
native=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$native/pruning.so" --reference "$stage2/.work/run/reference.so" --boundary "$native/boundary.so" --dual "$logs/dual.so" --attribution "$stage2/research/mirf-muformer/audit/phylo-f81-math-attribution-20261121/attribution-summary.json")
run() {
    local label=$1
    shift
    /usr/bin/time -v -o "$logs/$label.time" python3 -m perf.check_f81_edge_conditioning "${common[@]}" --case "$label" "$@" > "$logs/$label.json" 2> "$logs/$label.stderr"
    printf '%s %s complete\n' "$(date -Iseconds)" "$label"
}
run short-10000 --checkpoint "$prior/scaled-10000.npy" --manifest "$prior/scaled-10000.json" &
p1=$!
run previous-10000 --checkpoint "$prior/archived.npy" --manifest "$prior/archived.json" &
p2=$!
run warm-10000 --checkpoint "$prior/scaled-10000.npy" --manifest "$comparison/archived-10000-baseline.json" --warm-trace "$comparison/archived-10000-baseline.jsonl" &
p3=$!
failed=0
wait "$p1" || failed=1
wait "$p2" || failed=1
wait "$p3" || failed=1
exit "$failed"
