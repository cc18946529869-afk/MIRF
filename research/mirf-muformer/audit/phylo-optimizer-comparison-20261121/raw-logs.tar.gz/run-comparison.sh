#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-optimizer-comparison-20261121
logs="$work/.work/run"
archive=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121/.work/run
native=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$native/pruning.so" --boundary "$native/boundary.so" --archive "$archive")
run() {
    local start=$1 rows=$2 arm=$3 label="$1-$2-$3"
    if /usr/bin/time -v -o "$logs/$label.time" timeout --signal=TERM --kill-after=10s 2400s python3 -m perf.check_f81_optimizer_comparison "${common[@]}" --start "$start" --rows "$rows" --strategy "$arm" --trace "$logs/$label.jsonl" > "$logs/$label.json" 2> "$logs/$label.stderr"; then
        printf '%s %s complete\n' "$(date -Iseconds)" "$label"
    else
        status=$?
        printf '%s %s exit=%d\n' "$(date -Iseconds)" "$label" "$status" >&2
        return "$status"
    fi
}
batch() {
    local start=$1 rows=$2
    shift 2
    local pid failed=0
    local pids=()
    for arm in "$@"; do
        run "$start" "$rows" "$arm" &
        pids+=("$!")
    done
    for pid in "${pids[@]}"; do
        wait "$pid" || failed=1
    done
    return "$failed"
}
batch short 1000 baseline expansion recovery combined
batch short 10000 baseline expansion recovery combined
batch archived 10000 baseline expansion recovery combined
batch archived 1000 baseline expansion recovery combined
batch short 1000 normalized
batch archived 1000 normalized
run short 10000 normalized &
p1=$!
run archived 10000 normalized &
p2=$!
failed=0
wait "$p1" || failed=1
wait "$p2" || failed=1
exit "$failed"
