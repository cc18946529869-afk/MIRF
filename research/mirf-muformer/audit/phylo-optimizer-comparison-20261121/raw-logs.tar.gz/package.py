"""Verify each objective evaluation, Armijo decision, and terminal gate."""
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import tarfile

work = Path(".work")
logs = work / "run"
out = Path("research/mirf-muformer/audit/phylo-optimizer-comparison-20261121")
out.mkdir(parents=True, exist_ok=True)
arms = ("baseline", "expansion", "recovery", "combined", "normalized")


def audit(name, data):
    path = logs / f"{name}.jsonl"
    events = (json.loads(line) for line in path.read_text().splitlines())
    calls = accepted = 0
    evaluated = None
    candidates = {}
    previous = float("inf")
    counts = Counter()
    method_counts = Counter()
    search = 0
    attempts = 0
    for row in events:
        kind = row["event"]
        if kind == "line_search":
            assert evaluated is None
            attempts = 0
            search = row["search"]
            method_counts[row["method"]] += 1
            candidates = {}
        elif kind == "evaluation":
            calls += 1
            assert calls == row["call"] <= 260
            evaluated = row if calls > 1 else None
            if calls == 1:
                previous = -row["log_likelihood"] / data["sites"]
        elif kind == "line_trial":
            attempts += 1
            assert row["search"] == search and row["attempt"] == attempts <= 24
            outcome = row["outcome"]
            counts[outcome] += 1
            if outcome in ("accepted", "armijo_candidate", "armijo_rejected", "zero_likelihood"):
                assert evaluated is not None
                counts["charged_trial"] += 1
                if row.get("phase") == "expansion":
                    counts["charged_expansion"] += 1
                if outcome == "zero_likelihood":
                    assert not evaluated["finite"]
                else:
                    q = row["projected_directional_derivative"]
                    rhs = row["current_value"] + 0.0001 * q
                    assert q < 0 and rhs >= 0 and rhs == row["armijo_rhs"]
                    objective = -evaluated["log_likelihood"] / data["sites"]
                    assert objective == row["trial_value"]
                    assert (objective <= rhs) == (outcome != "armijo_rejected")
                    if outcome != "armijo_rejected":
                        candidates[evaluated["call"]] = objective
            else:
                assert evaluated is None
            evaluated = None
        elif kind == "accepted":
            assert candidates[row["calls"]] == min(candidates.values())
            objective = candidates[row["calls"]]
            assert objective <= previous
            previous = objective
            accepted += 1
            assert row["iteration"] == accepted
    fit = data["search"]
    assert evaluated is None and accepted == fit["iterations"] <= fit["maxiter"] == 150
    assert calls == fit["solver_likelihood_gradient_evaluations"] <= fit["maxeval"] == 260
    assert counts["charged_trial"] == calls - 1
    assert counts["charged_expansion"] == fit["expansion_evaluations"]
    assert previous == data["terminal_mean_negative_log_likelihood"]
    assert data["armijo_c1"] == 1e-4 and fit["gtol_per_site"] == 1e-5
    final = data["independent_terminal"]
    assert final["feasible_by_zero_guard"]
    assert (final["gradient_max_abs_difference"] <= 1e-8) == final["gradient_agreement_passed"]
    assert (final["projected_gradient_inf"] <= 1e-5) == final["projected_gradient_passed"]
    assert data["passes_both_gates"] == (fit["passed"] and final["gradient_agreement_passed"]
                                        and final["projected_gradient_passed"])
    return {"trial_outcomes": dict(counts), "search_method_counts": dict(method_counts),
            "all_actual_trials_charged": True, "armijo_and_incumbent_verified": True}


results, checks = {}, {}
for start in ("short", "archived"):
    for n in (1000, 10000):
        common = None
        for strategy in arms:
            name = f"{start}-{n}-{strategy}"
            data = json.loads((logs / f"{name}.json").read_text())
            results[name] = data
            checks[name] = audit(name, data)
            fingerprint = [data[k] for k in ("initial_sha256", "alignment_weights_sha256",
                                            "indices_sha256", "topology_sha256", "reference_profile_sha256",
                                            "library_sha256")]
            if common is None:
                common = fingerprint
            assert fingerprint == common
            if start == "short" and strategy == "baseline":
                assert data["baseline_matches_prior_exactly"]

allowed = {".json", ".jsonl", ".stderr", ".stdout", ".time"}
members = [p for p in logs.rglob("*") if p.is_file() and (p.suffix in allowed or p.name in ("stdout", "stderr"))]
members.extend(work / name for name in ("run-comparison.sh", "package.py", "environment.txt"))
with tarfile.open(out / "raw-logs.tar.gz", "w:gz") as archive:
    for path in sorted(members):
        payload = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to(work)))
        info.size = len(payload)
        archive.addfile(info, io.BytesIO(payload))
data = {"cases": results, "independent_ledger_check": checks,
        "raw_logs_sha256": hashlib.sha256((out / "raw-logs.tar.gz").read_bytes()).hexdigest()}
(out / "results.json").write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
for name, data in results.items():
    f = data["search"]
    x = data["independent_terminal"]
    print(name, f["status"], f["iterations"], f["solver_likelihood_gradient_evaluations"],
          data["terminal_mean_negative_log_likelihood"], x["projected_gradient_inf"],
          x["gradient_max_abs_difference"], f["curvature_pairs_kept"], f["history_resets"],
          f["expansion_evaluations"], f["expansion_selections"], f["search_seconds"])
