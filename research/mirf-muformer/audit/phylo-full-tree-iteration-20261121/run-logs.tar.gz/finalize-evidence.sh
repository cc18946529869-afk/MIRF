#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-full-tree-iteration-20261121
cd "$work"
run="$work/.work/run"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
until test -s "$run/short-10000.json" && test -s "$run/warm-10000.json" && test -s "$run/previous-10000.json" && test -s "$run/short-coupling.json"; do
    if ! kill -0 "$(cat "$work/.work/run.pid")" 2>/dev/null && ! kill -0 "$(cat "$run/short-coupling.pid")" 2>/dev/null; then
        printf '%s\n' 'A required run exited without results.' >&2
        exit 1
    fi
    sleep 5
done
python3 .work/package.py
python3 .work/render-report.py
(
    cd research/mirf-muformer/audit/phylo-full-tree-iteration-20261121
    sha256sum README.md results.json trajectory.csv run-logs.tar.gz > SHA256SUMS
    sha256sum -c SHA256SUMS
)
date -Iseconds
