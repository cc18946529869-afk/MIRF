"""Verify Stage 2.6 traces, summarize outcomes, and package the raw evidence."""
import csv
from decimal import Decimal, localcontext
import hashlib
import io
import json
from pathlib import Path
import tarfile

import numpy as np

work = Path(".work")
logs = work/"run"
out = Path("research/mirf-muformer/audit/phylo-full-tree-iteration-20261121")
out.mkdir(parents=True, exist_ok=True)
cases = {}
csv_rows = []


def audit_precision(audit, summary):
    mismatch = summary["max_gradient_disagreement"]
    assert audit["edge"] == mismatch["edge"]
    binary = audit["binary64"]
    assert binary["ordinary"] == mismatch["ordinary"]
    assert binary["rerooted_log"] == mismatch["rerooted_log"]
    assert binary["cross_path_abs"] == summary["cross_path_gradient_abs"]
    assert binary["cross_path_ulp_distance"] == mismatch["ulp_distance"]
    canonical = Decimal(audit["higher_precision_paths"]["256"]["split"])
    for check in audit["higher_precision_paths"].values():
        assert abs(Decimal(check["split"])-canonical) == Decimal(check["split_abs_to_256bit_reference"])
        assert abs(Decimal(check["tangent"])-canonical) == Decimal(check["tangent_abs_to_256bit_reference"])


with localcontext() as ctx:
    ctx.prec = 115
    for label in ("short-10000", "warm-10000", "previous-10000"):
        summary = json.loads((logs/f"{label}.json").read_text())
        trace = [json.loads(line) for line in (logs/f"{label}.jsonl").read_text().splitlines()]
        state = summary["initial"]
        accepted = []
        counts = {"replay": trace[0]["replay_evaluations"], "full_tree": 2,
                  "scalar_conditioned": 0, "high_precision_split": 0, "high_precision_tangent": 0,
                  "high_precision_scalar_terminal": 0}
        at_three = None
        for r in trace:
            if r["event"] == "stage25_discrepancy":
                assert len(accepted) == 3 and at_three == state
                audit_precision(r["audit"], state)
                assert r["audit"] == summary["stage25_short_discrepancy_audit"]
                counts["high_precision_split"] += 2
                counts["high_precision_tangent"] += 2
                continue
            if r["event"] != "proposal":
                continue
            candidate = r["after_proposal"]
            assert r["before"] == state and r["zero_edge_check_passed"]
            local = r["local_strategies"][0]
            counts["scalar_conditioned"] += local["evaluations"]
            assert len(local["trials"])+1 == local["evaluations"] <= 96
            for name, source in (("full_tree", "candidate_full_gradient_calls"),
                                 ("high_precision_split", "split_calls"), ("high_precision_tangent", "tangent_calls"),
                                 ("high_precision_scalar_terminal", "candidate_high_precision_response_calls")):
                counts[name] += r[source]
            for step in local["trials"]:
                if step["accepted"]:
                    assert Decimal(step["projected_slope"]) < 0
                    assert Decimal(step["objective"]) <= Decimal(step["armijo_rhs"])
            if r["retained"]:
                assert candidate["total_log_likelihood"] >= state["total_log_likelihood"]
                assert candidate["rerooted_log_likelihood"] >= state["rerooted_log_likelihood"]
                assert candidate["projected_gradient_inf"] < state["projected_gradient_inf"]
                assert candidate["rerooted_projected_gradient_inf"] < state["rerooted_projected_gradient_inf"]
                accepted.append(r["edge"])
                state = candidate
                if len(accepted) == 3:
                    at_three = state
            csv_rows.append({"case": label, "iteration": r["iteration"], "retained": r["retained"],
                             "edge": r["edge"], "start_length": local["start_length"], "end_length": local["end_length"],
                             "candidate_total_log_likelihood": candidate["total_log_likelihood"],
                             "independent_candidate_total_log_likelihood": candidate["rerooted_log_likelihood"],
                             "candidate_independent_projected_gradient": candidate["rerooted_projected_gradient_inf"],
                             "candidate_cross_path_max_abs": candidate["cross_path_gradient_abs"],
                             "cross_path_max_edge": candidate["max_gradient_disagreement"]["edge"],
                             "cumulative_full_tree_evaluations": counts["full_tree"],
                             "cumulative_scalar_evaluations": counts["scalar_conditioned"],
                             "elapsed_seconds": r["elapsed_seconds"]})
        if not (summary["stage25_short_discrepancy_audit"] and len(accepted) == 3):
            counts["high_precision_split"] += 2
            counts["high_precision_tangent"] += 2
        assert counts == summary["evaluation_counts"]
        assert accepted == summary["retained_edges"] and state == summary["terminal"]
        assert len(accepted) >= 3 and summary["stage25_three_updates_reproduced"]
        assert summary["terminal_zero_edge_check_passed"]
        passed = (max(state["projected_gradient_inf"], state["rerooted_projected_gradient_inf"]) <= 1e-5
                  and state["cross_path_gradient_abs"] <= 1e-8)
        assert passed == summary["both_frozen_gates_passed"]
        assert hashlib.sha256(np.load(logs/f"{label}.npy", allow_pickle=False).tobytes()).hexdigest() == summary["terminal_sha256"]
        audit_precision(summary["terminal_discrepancy_audit"], state)
        cases[label] = summary

with (out/"trajectory.csv").open("w", encoding="utf-8", newline="") as stream:
    table = csv.DictWriter(stream, fieldnames=list(csv_rows[0]), lineterminator="\n")
    table.writeheader()
    table.writerows(csv_rows)

members = [p for p in logs.iterdir() if p.is_file() and (p.suffix in {".jsonl", ".stderr", ".stdout", ".time"}
                                                       or p.name in {"run.stdout", "run.stderr"})]
coupling = json.loads((logs/"short-coupling.json").read_text())
assert coupling["terminal_sha256"] == cases["short-10000"]["terminal_sha256"]
assert coupling["actual_high_precision_tangent_calls"] == 12
members += [work/name for name in ("run-full-iters.sh", "package.py", "render-report.py", "finalize-evidence.sh", "environment.txt", "check-short-coupling.py")]
with tarfile.open(out/"run-logs.tar.gz", "w:gz") as archive:
    for path in sorted(members):
        payload = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to(work)))
        info.size = len(payload)
        archive.addfile(info, io.BytesIO(payload))
members_checked = all(x["terminal_zero_edge_check_passed"] for x in cases.values())
assert members_checked
result = {"cases": cases, "short_terminal_cross_branch_diagnostic": coupling, "stage26_passed": all(x["both_frozen_gates_passed"] for x in cases.values()),
          "run_logs_sha256": hashlib.sha256((out/"run-logs.tar.gz").read_bytes()).hexdigest()}
(out/"results.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
for label, data in cases.items():
    print(label, data["status"], len(data["retained_edges"]), data["proposed_updates"],
          data["initial"]["rerooted_projected_gradient_inf"],
          data["terminal"]["rerooted_projected_gradient_inf"],
          data["terminal"]["cross_path_gradient_abs"], data["elapsed_seconds"])
