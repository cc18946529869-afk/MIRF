"""One-column physical Hessian check at the retained short-start checkpoint."""
from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

from perf.check_f81_edge_conditioning import TangentReference
from perf.check_f81_observed_bridge import load_case
from perf.f81_zero_boundary import ZeroBoundary

prep, gate, native, boundary, dual, checkpoint, summary, ledger = map(Path, sys.argv[1:])
point = np.load(checkpoint, allow_pickle=False)
terminal = json.loads(summary.read_text())
assert hashlib.sha256(point.tobytes()).hexdigest() == terminal["terminal_sha256"]
attempts = [json.loads(line) for line in ledger.read_text().splitlines()]
proposal = next(r for r in reversed(attempts) if r["event"] == "proposal")
assert not proposal["retained"]
edge = proposal["edge"]
local = proposal["local_strategies"][0]
engine, auditor, facts = load_case(prep, gate, 10000, native)
for key in ("alignment_weights_sha256", "indices_sha256", "reference_profile_sha256",
            "topology_sha256", "library_sha256"):
    assert facts[key] == terminal[key]
guard = ZeroBoundary(engine, boundary)
other = [row["edge"] for row in terminal["terminal_residual_distribution"]["top"] if row["edge"] != edge][:2]
tangent = TangentReference(auditor, dual)
with localcontext() as ctx:
    ctx.prec = 115
    scale = abs(Decimal(local["gradient_s"])/Decimal(local["diagonal_s"]))
    step = scale*Decimal("1e-4")
    sampled = []
    for ratio in (0, Decimal(".5"), 1, 2):
        candidate = point.copy()
        candidate[edge] = float(Decimal.from_float(point[edge])+step*ratio)
        assert guard.feasible(candidate)
        dx = Decimal.from_float(candidate[edge])-Decimal.from_float(point[edge])
        sampled.append((dx, {j: tangent.score(candidate, j, 256) for j in [edge, *other]}))

    def one_sided(j, i, k):
        h1, h2 = sampled[i][0], sampled[k][0]
        original = sampled[0][1][j]
        u, v = sampled[i][1][j]-original, sampled[k][1][j]-original
        return (h2*h2*u-h1*h1*v)/(h1*h2*(h2-h1))

    column = {}
    for target in [edge, *other]:
        coarse, fine = one_sided(target, 2, 3), one_sided(target, 1, 2)
        column[str(target)] = {"coarse": str(coarse), "fine": str(fine),
                               "relative_disagreement": str(abs(coarse-fine)/max(abs(coarse), abs(fine)))}
    out = {"perturbed_edge": edge, "terminal_sha256": terminal["terminal_sha256"],
           "sample": [{"physical_perturbation": str(dx), "gradient": {str(k): str(v) for k, v in g.items()}}
                      for dx, g in sampled], "physical_hessian_column": column,
           "actual_high_precision_tangent_calls": len(sampled)*(1+len(other)),
           "scope": "diagnostic only; fixed other edges and preserved the archived terminal"}
    print(json.dumps(out, indent=2, allow_nan=False))
