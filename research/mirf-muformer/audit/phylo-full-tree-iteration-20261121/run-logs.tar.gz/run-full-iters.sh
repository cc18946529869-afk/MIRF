#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-full-tree-iteration-20261121
run="$work/.work/run"
stage25=/data/cc233_data/work_dir/MIRF-phylo-boundary-conditioning-20261121
checkpoints=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121/.work/run
comparison=/data/cc233_data/work_dir/MIRF-phylo-optimizer-comparison-20261121/.work/run
stage2=/data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121
native=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$native/pruning.so" --boundary "$native/boundary.so" --reference "$stage2/.work/run/reference.so" --dual "$stage25/.work/run/dual.so" --stage25 "$stage25/research/mirf-muformer/audit/phylo-boundary-conditioning-20261121/results.json" --max-wall-seconds 2400)
run_case() {
    local label=$1
    shift
    /usr/bin/time -v -o "$run/$label.time" python3 -m perf.check_f81_full_tree_iteration "${common[@]}" --case "$label" --trace "$run/$label.jsonl" --out-checkpoint "$run/$label.npy" "$@" > "$run/$label.json" 2> "$run/$label.stderr"
    printf '%s %s complete\n' "$(date -Iseconds)" "$label"
}
run_case short-10000 --checkpoint "$checkpoints/scaled-10000.npy" --manifest "$checkpoints/scaled-10000.json" &
p1=$!
run_case previous-10000 --checkpoint "$checkpoints/archived.npy" --manifest "$checkpoints/archived.json" &
p2=$!
run_case warm-10000 --checkpoint "$checkpoints/scaled-10000.npy" --manifest "$comparison/archived-10000-baseline.json" --warm-trace "$comparison/archived-10000-baseline.jsonl" &
p3=$!
failed=0
wait "$p1" || failed=1
wait "$p2" || failed=1
wait "$p3" || failed=1
exit "$failed"
