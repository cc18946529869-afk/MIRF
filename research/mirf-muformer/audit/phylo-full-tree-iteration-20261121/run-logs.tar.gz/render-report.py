"""Render the reviewed Stage 2.6 audit summary from the verified ledgers."""
from pathlib import Path
import json

out = Path("research/mirf-muformer/audit/phylo-full-tree-iteration-20261121")
result = json.loads((out/"results.json").read_text())
cases = result["cases"]
labels = {"short-10000": "短初值尺度修复", "warm-10000": "后续归档基线", "previous-10000": "旧停机点"}
statuses = {"full_tree_projection_did_not_decrease": "候选未降低全树投影梯度",
            "projection_plateau": "投影梯度平台",
            "repeating_coordinate_cycle": "重复坐标周期",
            "full_tree_objective_increase": "完整目标上升",
            "no_local_move": "单枝无可验收移动",
            "proposal_failed_validation": "候选未通过独立验证",
            "both_frozen_gates": "两项门槛同时通过",
            "diagnostic_wall_budget": "诊断墙钟上限"}

text = ["""# Stage 2.6 · 固定拓扑全树迭代

通过所有门槛的检查点为 **{passed}/3**。冻结的混合零枝／对数正枝方案沿完整树上最大独立投影残差逐枝更新。每次候选先过原物理坐标 Armijo 和精确零边检查，再以两条路径核对整树似然与投影残差。只保留目标不增加且两条最大残差均下降的候选。

三个检查点均逐值复现了 Stage 2.5 的前三次更新。此后用同一方法继续，未重选条件求解器或扩大 96 次单枝求值上限。预设停止条件包括首个无可验收的全树提案、8 次保留更新内独立投影梯度总降幅至多 1%、同一有序坐标序列连续出现三遍，以及测试用 2,400 秒安全上限。

## 全树结果

| 检查点 | 保留 / 提案 | 初始独立投影梯度 | 终点独立投影梯度 | 终点全向量梯度绝对差 | 停止 |
| --- | ---: | ---: | ---: | ---: | --- |
""".format(passed=sum(x["both_frozen_gates_passed"] for x in cases.values()))]
for label, x in cases.items():
    text.append(f"| {labels[label]} | {len(x['retained_edges'])} / {x['proposed_updates']} | "
                f"{x['initial']['rerooted_projected_gradient_inf']:.6g} | "
                f"{x['terminal']['rerooted_projected_gradient_inf']:.6g} | "
                f"{x['terminal']['cross_path_gradient_abs']:.6g} | {statuses[x['status']]} |\n")
text.append("""
全树门槛仍为投影梯度 $10^{-5}$ 和跨路径最大绝对差 $10^{-8}$。所有保留点满足精确零边可行性。表内的独立全向量复算采用不同内部根和强制对数域；两档独立高精度计算核对指定坐标。每一实际全树、条件和高精度求值单独入账，包含拒绝提案和归档重放。

## Stage 2.5 短初值终点的差异枝

第 **17428** 条枝，长度 $3.252684129473125\\times10^{-10}$。两条 binary64 梯度分别为 `−58394702.07118239` 和 `−58394702.07118236`。绝对差 $2.9802322387695312\\times10^{-8}$，对称相对差 $5.10\\times10^{-16}$，距离 **4 ULP**。

最近 binary64 值相对 256-bit 参考的误差为 $2.46\\times10^{-9}$，在冻结容差内。普通路径与参考相差 $4.99\\times10^{-9}$，对数域路径相差 $3.48\\times10^{-8}$，分别距最近 binary64 为 1 和 5 ULP。枝切分和独立前向微分之间的绝对差在 192 bit 为 $1.0\\times10^{-50}$、256 bit 为 $1.16\\times10^{-69}$。因此该坐标允许用 binary64 满足绝对门槛，实际超差来自计算路径。第 4 次更新后，短初值组的全向量差已降至约 $8.15\\times10^{-10}$。

## 剩余残差

短初值组在第 5 次提案停于枝 **1310**。该枝为 $1.147\\times10^{-24}$，物理梯度约 $-2.5152\\times10^5$，对数梯度约 $-2.88\\times10^{-19}$。既有对角保护在这个尺度下把对数步压到约 $2.88\\times10^{-11}$。96 次局部求值只令枝长变化约 $3.14\\times10^{-33}$。条件平均目标的精确减幅约 $7.90\\times10^{-28}$，完整树的两条投影梯度均保持原值。此提案未被保留。

在保留终点对枝 1310 做单边扰动，用 256-bit 前向微分复核梯度。第 1310、10655 和 15327 条枝的梯度对这一物理扰动的斜率分别约为 $1.66381444\\times10^{13}$、$1.66381442\\times10^{13}$ 和 $1.66381437\\times10^{13}$。两档差分相对差约 $1.5\\times10^{-8}$。这 12 次高精度诊断调用单独入账，未更新检查点。证据是该 Hessian 列的局部结果。
""")
for label, x in cases.items():
    t = x["terminal_residual_distribution"]
    budget = x["evaluation_counts"]
    point = t["top"][0]
    text.append(f"\n- {labels[label]}终点仍有 {t['counts_above']['1e-05']:,} 个枝残差超过 $10^{{-5}}$，"
                f"最大残差位于枝 {point['edge']}。记录 {budget['full_tree']} 次全树、"
                f"{budget['scalar_conditioned']} 次单枝条件求值。"
                f"跨路径绝对差{'通过' if x['terminal']['cross_path_gradient_passed'] else '未通过'}。\n")
    d = x["stop_diagnosis"]
    transfer = d.get("cross_edge_residual_transfer") if d else None
    if transfer and transfer["largest_increases"]:
        change = transfer["largest_increases"][0]
        candidate_max = d["candidate"]["top"][0]
        text.append(f"  单枝残差降至 {transfer['chosen_abs_after']:.6g}，"
                    f"候选的全树最大残差却移至枝 {candidate_max['edge']}，达到 "
                    f"{candidate_max['abs_projected_residual']:.6g}。\n")
        text.append(f"  停机候选中，未更新的枝 {change['edge']} 的绝对残差由 "
                    f"{change['before']:.6g} 增至 {change['after']:.6g}。"
                    f"共有 {transfer['other_edges_increased']:,} 条其他枝的残差增加。\n")

text.append("""
[逐次收敛轨迹](trajectory.csv) · [独立审计摘要与计数](results.json) · [完整试探日志和复现脚本](run-logs.tar.gz) · [SHA-256](SHA256SUMS)
""")
(out/"README.md").write_text("".join(text))
