#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121
logs="$work/.work/run"
prior=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121/.work/run
comparison=/data/cc233_data/work_dir/MIRF-phylo-optimizer-comparison-20261121/.work/run
native=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$native/pruning.so" --reference "$logs/reference.so")
run() {
    local name=$1
    shift
    /usr/bin/time -v -o "$logs/$name.time" python3 -m perf.check_f81_gradient_attribution "${common[@]}" --edge-ledger "$logs/$name.edges.jsonl.gz" "$@" > "$logs/$name.json" 2> "$logs/$name.stderr"
    printf '%s %s complete\n' "$(date -Iseconds)" "$name"
}
run short-1000 --rows 1000 --checkpoint "$prior/scaled-1000.npy" --manifest "$prior/scaled-1000.json" &
p1=$!
run short-10000 --rows 10000 --checkpoint "$prior/scaled-10000.npy" --manifest "$prior/scaled-10000.json" &
p2=$!
run previous-10000 --rows 10000 --checkpoint "$prior/archived.npy" --manifest "$prior/archived.json" &
p3=$!
failed=0
wait "$p1" || failed=1
wait "$p2" || failed=1
wait "$p3" || failed=1
run warm-10000 --rows 10000 --checkpoint "$prior/scaled-10000.npy" --manifest "$comparison/archived-10000-baseline.json" --warm-trace "$comparison/archived-10000-baseline.jsonl" || failed=1
exit "$failed"
