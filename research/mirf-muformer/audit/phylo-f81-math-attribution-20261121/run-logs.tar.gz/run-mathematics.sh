#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121
native=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
out="$work/.work/run"
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1
/usr/bin/time -v -o "$out/mathematics.time" python3 -m perf.check_f81_recoverability --library "$native/pruning.so" --boundary "$native/boundary.so" --reference "$out/reference.so" > "$out/mathematics.json" 2> "$out/mathematics.stderr"
