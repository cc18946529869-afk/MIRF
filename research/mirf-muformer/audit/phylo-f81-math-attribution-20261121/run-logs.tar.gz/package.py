"""Validate and package small-tree recovery and numerical gradient attribution."""
from collections import Counter
from decimal import Decimal, localcontext
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

work = Path(".work")
run = work / "run"
out = Path("research/mirf-muformer/audit/phylo-f81-math-attribution-20261121")
out.mkdir(parents=True, exist_ok=True)
model = json.loads((run/"mathematics.json").read_text())
assert model["exhaustive_passed"] and model["recovery"]["all_passed"]
assert len(model["recovery"]["cases"]) == 81
assert all(r["solver_evaluations"] <= 260 for r in model["recovery"]["cases"])
fits = model["recovery"]["cases"]
model["evaluation_accounting"] = {
    "synthetic_optimizer_evaluations": sum(x["solver_evaluations"] for x in fits),
    "synthetic_optimizer_terminal_rechecks": sum(x["solver_terminal_evaluations"] for x in fits),
    "synthetic_independent_terminal_evaluations": sum(x["independent_terminal_objective_or_gradient_evaluations"] for x in fits),
    "synthetic_slsqp_evaluations": sum(x["oracle_evaluations"] for x in fits if x["start_id"] == 0),
    "synthetic_slsqp_terminal_rechecks": sum(x["oracle_extra_terminal_evaluations_per_sample"] for x in fits if x["start_id"] == 0),
    "exhaustive_native_evaluations_per_truth": 81 * (1 + 2 * 2 * 5),
    "exhaustive_all_zero_conflict_evaluations": 1,
    "exhaustive_high_precision_split_calls_per_truth": 10,
    "first_attempt_native_evaluations": 81 * (1 + 2 * 5) * 3,
    "first_attempt_high_precision_split_calls": 30,
}
(out/"mathematics.json").write_text(json.dumps(model, indent=2, allow_nan=False) + "\n")

summary, detail = {}, {}
for name in ("short-1000", "short-10000", "previous-10000", "warm-10000"):
    case = json.loads((run/f"{name}.json").read_text())
    ledger_path = run/f"{name}.edges.jsonl.gz"
    assert hashlib.sha256(ledger_path.read_bytes()).hexdigest() == case["edge_ledger_sha256"]
    with gzip.open(ledger_path, "rt", encoding="utf-8") as stream:
        edges = [json.loads(line) for line in stream]
    assert len(edges) == case["edges_scanned"]
    assert max(abs(x["ordinary_gradient"]-x["rerooted_log_gradient"]) for x in edges) == case["cross_path_gradient_max_abs_difference"]
    assert max(abs(x["projected_residual"]) for x in edges) == case["ordinary_projected_gradient_inf"]
    detail[name] = {}
    case["independent_high_precision_split_calls"] = 2 * len(case["selected_edge_site_attributions"])
    for edge in case["selected_edge_site_attributions"]:
        rows = edge.pop("site_terms")
        edge_id = edge["edge_index"]
        assert len(rows) == case["sites"] and edges[edge_id]["length"] == edge["branch_length"]
        assert edge["left_leaves"] + edge["right_leaves"] == case["sample_size"]
        assert dict(Counter(t["classification"] for t in rows)) == edge["site_class_counts"]
        with localcontext() as ctx:
            ctx.prec = 115
            scores = [Decimal(t["bits256"]["gradient"]) for t in rows]
            assert sum(scores) == Decimal(edge["summed_site_gradient_256bit"])
            assert sum(Decimal(t["bits256"]["diagonal_curvature"]) for t in rows) / len(rows) == Decimal(edge["mean_local_diagonal_curvature_256bit"])
            assert abs(sum(t["absolute_gradient_fraction"] for t in rows)-1) < 1e-12
        edge["top_sites"] = [rows[i] for i in edge["top_site_indices"]]
        detail[name][str(edge_id)] = rows
    summary[name] = case
(out/"site-terms.json.gz").write_bytes(gzip.compress(json.dumps(detail, allow_nan=False).encode(), mtime=0))
summary_path = out/"attribution-summary.json"
summary_path.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
members = [p for p in run.iterdir() if p.suffix in {".stderr", ".stdout", ".time", ".json"}
           and (not p.name.endswith("10000.json")) and not p.name.endswith("1000.json")]
members += [work / name for name in ("package.py", "run-attribution.sh", "run-mathematics.sh", "environment.txt")]
with tarfile.open(out/"run-logs.tar.gz", "w:gz") as archive:
    for path in sorted(members):
        payload = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to(work)))
        info.size = len(payload)
        archive.addfile(info, io.BytesIO(payload))
print("all-edge scanned:", sum(case["edges_scanned"] for case in summary.values()))
print("selected branch decompositions:", sum(len(case["selected_edge_site_attributions"]) for case in summary.values()))
print("exhaustive and sampled recovery:", model["exhaustive_passed"], model["recovery"]["all_passed"])
