#!/usr/bin/env bash
set -euo pipefail
cd /data/cc233_data/work_dir/MIRF-phylo-joint-20261121
while ! (test -s .work/run/short-10000.json && test -s .work/run/warm-10000.json && test -s .work/run/previous-10000.json && test -s .work/run/block-fine.json); do
    if ! kill -0 "$(cat .work/final.pid)" 2>/dev/null && ! kill -0 "$(cat .work/block-fine.pid)" 2>/dev/null; then
        echo 'At least one job has exited without a complete result.' >&2
        exit 1
    fi
    sleep 8
done
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site OPENBLAS_NUM_THREADS=1
python3 .work/package.py
