#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-joint-20261121
logs="$work/.work/run"
previous=/data/cc233_data/work_dir/MIRF-phylo-full-tree-iteration-20261121
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
/usr/bin/time -v -o "$logs/block-fine.time" python3 -m perf.check_f81_joint --prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$logs/joint-pruning.so" --boundary /data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials/boundary.so --reference /data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121/.work/run/reference.so --dual /data/cc233_data/work_dir/MIRF-phylo-boundary-conditioning-20261121/.work/run/dual.so --stage26 "$previous/research/mirf-muformer/audit/phylo-full-tree-iteration-20261121/results.json" --case short-10000 --checkpoint "$previous/.work/run/short-10000.npy" --block --block-step 1.5e-18 > "$logs/block-fine.json" 2> "$logs/block-fine.stderr"
