"""Render the joint-optimizer implementation and its audited trials."""
from pathlib import Path
import json

import numpy as np

out = Path("research/mirf-muformer/audit/phylo-joint-20261121")
d = json.loads((out/"results.json").read_text())
labels = {"short-10000": "短初值尺度修复", "warm-10000": "后续归档基线", "previous-10000": "旧停机点"}
stops = {"candidate_stationary": "常规路径达到候选驻点",
         "objective_budget": "全树目标求值上限", "iteration_limit": "接受步上限",
         "line_search_stopped": "无可接受线搜索步"}
passed = sum(x["both_gates_passed"] for x in d["cases"].values())
report = [f"""# Stage 2.7 · 全树预条件联合优化

**{passed}/3 通过固定检查点验收。** 三组均从 Stage 2.6 保留终点启动，核对同一终点指纹和 MSA、权重、位点组成及拓扑指纹。优化产生的检查点单独保存在服务器，Stage 2.6 历史档案作为只读输入。

## 实现

剪枝在同一次下行累积每个枝的对数似然一阶导数和负对数似然对角曲率。对每个观察位点使用 $H_{{ss}}=g_s(g_s-1)$，再按位点累积。作为初始逆 Hessian 的对角缩放使用 $1/\\max(|H_{{ii}}|,|g_i|/\\Delta_i)$。正枝在对数坐标中取曲率 $s^2H_{{ss}}+sg_s$，零枝处使用物理坐标和单边 KKT。线搜索可提出显式回零，任何候选都需要经过精确 ZeroBoundary。没有设置正枝长下限。

全树 L-BFGS 每次同时产生整个候选向量。坐标或自由状态发生变化时，对历史曲率对限制到共同自由坐标，并重新核对正曲率。正式验收前的短连通运行曾在每次坐标切换时清空全部历史，导致有限记忆不工作；该次未完成运行单独归档。正式三组使用相同的共同自由坐标规则和同一组参数，从原始 Stage 2.6 终点重新启动。

接受条件为原物理坐标 Armijo、有限性与精确零枝可行性。目标差先按位点相减再归约，以减少大目标值相减带来的误差；接受状态的梯度与对角复算也核对 Armijo。最大投影梯度只参与监测和终点验收。每 25 步与终点用另一内部根和强制对数域复核。正式上限为 1,500 次常规目标求值和 600 个接受步，每方向至多 24 次试探，L-BFGS 历史最多 10 对。原 $10^{{-5}}$ 投影梯度及 $10^{{-8}}$ 跨路径绝对差门槛保持冻结。

## 固定检查点验收

| 起点 | 接受步 | 初始 → 最终平均负对数似然 | 终点独立投影梯度 | 全向量跨路径绝对差 | 停止 |
| --- | ---: | --- | ---: | ---: | --- |
"""]
for label, r in d["cases"].items():
    report.append(f"| {labels[label]} | {r['accepted']} | {r['initial_objective']:.8f} → {r['objective']:.8f} | "
                  f"{r['independent_projection']:.6g} | {r['cross_path_max']:.6g} | {stops[r['status']]} |\n")
report.append("""
所有终点通过精确零枝检查。以下计数把只算目标的线搜索和接受点带导数的复算分开记录，后者同时计入常规目标、梯度、曲率三列。独立路径以及终点最大差坐标的高精度复核另行计费。表中试探包含几何检查拒绝、尚未调用剪枝的候选。

| 起点 | 常规目标 / 梯度 / 对角 | 线搜索试探 | 独立目标及梯度 | 高精度终点坐标调用 | 保留曲率对 | 允许投影残差升高的接受步 | 每步改枝数中位数 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
""")
for label, r in d["cases"].items():
    n = r["counts"]
    report.append(f"| {labels[label]} | {n['objective']} / {n['gradient']} / {n['diagonal']} | "
                  f"{n['line_search_trials']} | {n['independent_gradient']} | 2 | {r['history_pairs']} | "
                  f"{r['accepted_with_projection_increase']} | {r['median_edges_changed_per_accepted_update']:.0f} |\n")
report.append("\n各组的路径最低投影梯度为常规路径的监测值。验收始终使用保留终点和独立复算。\n\n")
for label, r in d["cases"].items():
    o = r["line_search_outcomes"]
    report.append(f"- {labels[label]}路径最低常规投影梯度 {r['best_ordinary_projection']:.6g}。"
                  f"线搜索记录 {o.get('rejected', 0)} 个目标求值后拒绝的候选和 "
                  f"{o.get('zero_conflict', 0)} 个零边冲突。\n")
block = d["short_checkpoint_hessian_block"]
H = np.array(block["matrix"])
s = np.array(block["lengths"])
g = np.array(block["gradient"], dtype=float)
proposed = np.linalg.solve(H, -g)+s
hz = np.linalg.eigvalsh(s[:, None]*H*s[None, :]+np.diag(s*g))
errors = [v for case in d["mathematics"]["results"].values() for v in case.values()]
report.append(f"""
## 数学及块验证

四叶全枚举对照覆盖全正枝、零内部枝和零末端枝的全部 81 种叶端模式。两条剪枝路径的物理对角最大绝对误差为 {max(r['physical_diagonal'] for r in errors):.4g}，混合坐标对角最大绝对误差为 {max(r['mixed_diagonal'] for r in errors):.4g}。

在短初值 Stage 2.6 保留终点，对枝 1310、10655、15327 分别进行单边扰动，用独立 256-bit 前向导数填全 9 个 Hessian 元素。细步长外推块的特征值约为 {', '.join(f'{e:.5g}' for e in block['symmetric_eigenvalues'])}，条件数 {block['condition_estimate']:.5g}。对角线在转换到 binary64 后与独立切分解析值一致。粗步长产生的差分噪声不足以分辨最小特征值，细步长的两个级别在 binary64 输出上相同。粗细两轮各计 39 次独立高精度导数和 3 次解析枝切分。

未加阻尼的物理三枝 Newton 提案会把第 10655 条枝推至 $s={proposed[1]:.4g}$。同一点的对数坐标块有 {sum(v < 0 for v in hz)} 个负特征值。本轮全树更新采用对角保护和有限记忆曲率，未将只在这个固定点验证过的块直接装入全树求解器。
""")
cost = d.get("microbenchmark")
if cost:
    report.append("\n## 单次求值成本\n\n同一 10,000 行冻结检查点，4 个线程。以下为独立微基准中位数，调用数包含预热。\n\n")
    for route, entry in cost.items():
        if isinstance(entry, dict):
            report.append(f"- `{route}` 为 {entry['wall_median_seconds']:.4g} 秒，{entry['calls_including_warmup']} 次调用。\n")
    report.append("\n")
if not d["stage27_passed"]:
    report.append("\nStage 3 保持暂停，真实 MSA 桥接仍为 **NO-GO**。\n")
report.append("""
[逐步轨迹](trajectory.csv) · [验收账本及完整三枝块](results.json) · [原始日志与校验](run-logs.tar.gz) · [SHA-256](SHA256SUMS)
""")
(out/"README.md").write_text("".join(report), encoding="utf-8")
