"""Measure cost of the fixed-tree evaluation routes at one frozen point."""
import json
from pathlib import Path
import statistics
import sys
from time import perf_counter

import numpy as np

from perf.check_f81_edge_conditioning import TangentReference
from perf.check_f81_observed_bridge import load_case
from perf.check_f81_split_gradient import Reference
from perf.f81_zero_boundary import ZeroBoundary

prep, gate, library, boundary, split_lib, tangent_lib, checkpoint = map(Path, sys.argv[1:])
engine, auditor, facts = load_case(prep, gate, 10000, library)
point = np.load(checkpoint, allow_pickle=False)
guard = ZeroBoundary(engine, boundary)
split = Reference(engine, point, split_lib)
tangent = TangentReference(auditor, tangent_lib)


def measure(func, repeats):
    func()
    seconds = []
    for _ in range(repeats):
        start = perf_counter()
        func()
        seconds.append(perf_counter()-start)
    return {"calls_including_warmup": repeats+1, "wall_median_seconds": statistics.median(seconds),
            "timed_wall_seconds": seconds}


output = {
    "fixture": "Stage 2.6 short-10000 retained checkpoint",
    "objective_only": measure(lambda: engine.evaluate(point, gradient=False, threads=4), 5),
    "objective_gradient": measure(lambda: engine.evaluate(point, threads=4), 5),
    "objective_gradient_diagonal": measure(lambda: engine.evaluate(point, threads=4, diagonal=True), 5),
    "independent_log_gradient": measure(lambda: auditor.evaluate(point, threads=4, log_domain=True), 3),
    "zero_edge_guard": measure(lambda: guard.feasible(point), 5),
    "one_edge_split_256": measure(lambda: split.score(1310, 256), 2),
    "one_edge_tangent_256": measure(lambda: tangent.score(point, 1310, 256), 2),
}
print(json.dumps(output, indent=2))
