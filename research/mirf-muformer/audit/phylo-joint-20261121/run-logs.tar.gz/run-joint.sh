#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-joint-20261121
logs="$work/.work/run"
previous=/data/cc233_data/work_dir/MIRF-phylo-full-tree-iteration-20261121
mathematics=/data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121
conditioning=/data/cc233_data/work_dir/MIRF-phylo-boundary-conditioning-20261121
original=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$logs/joint-pruning.so" --boundary "$original/boundary.so" --reference "$mathematics/.work/run/reference.so" --dual "$conditioning/.work/run/dual.so" --stage26 "$previous/research/mirf-muformer/audit/phylo-full-tree-iteration-20261121/results.json")
run() {
    local label=$1
    shift
    /usr/bin/time -v -o "$logs/$label.time" python3 -m perf.check_f81_joint "$@" > "$logs/$label.json" 2> "$logs/$label.stderr"
    printf '%s %s complete\n' "$(date -Iseconds)" "$label"
}
run mathematics --check --library "$logs/joint-pruning.so"
for label in short-10000 warm-10000 previous-10000; do
    run "$label" "${common[@]}" --case "$label" --checkpoint "$previous/.work/run/$label.npy" --trace "$logs/$label.jsonl" --out-checkpoint "$logs/$label.npy" &
done
run block "${common[@]}" --case short-10000 --checkpoint "$previous/.work/run/short-10000.npy" --block &
failed=0
for child in $(jobs -p); do wait "$child" || failed=1; done
exit "$failed"
