"""Check Stage 2.7 full objective accounting and assemble its frozen-point evidence."""
from collections import Counter
import csv
import hashlib
import io
import json
from pathlib import Path
import statistics
import tarfile

import numpy as np

work = Path(".work")
logs = work/"run"
out = Path("research/mirf-muformer/audit/phylo-joint-20261121")
out.mkdir(parents=True, exist_ok=True)
cases, rows = {}, []
for label in ("short-10000", "warm-10000", "previous-10000"):
    r = json.loads((logs/f"{label}.json").read_text())
    if "history_resets" in r:
        r["history_clear_or_discard_count"] = r.pop("history_resets")
    trace = [json.loads(line) for line in (logs/f"{label}.jsonl").read_text().splitlines()]
    trials = [x for x in trace if x["event"] == "trial"]
    accepted = [x for x in trials if x["status"] == "accepted"]
    points = [x for x in trace if x["event"] == "iterate"]
    assert len(trials) == r["counts"]["line_search_trials"]
    assert len(points) == len(accepted) == r["accepted"]
    assert all(a["objective_change"] <= 1e-4*a["slope"] < 0 for a in accepted)
    assert r["counts"]["objective"] <= r["maxeval"]
    assert r["counts"]["gradient"] == r["counts"]["diagonal"]
    assert r["feasible"]
    assert r["both_gates_passed"] == (
        max(r["projection"], r["independent_projection"]) <= 1e-5 and r["cross_path_max"] <= 1e-8)
    assert hashlib.sha256(np.load(logs/f"{label}.npy", allow_pickle=False).tobytes()).hexdigest() == r["terminal_sha256"]
    residuals = [trace[0]["projection"], *(x["projection"] for x in points)]
    r["line_search_outcomes"] = dict(Counter(x["status"] for x in trials))
    r["initial_objective"] = trace[0]["objective"]
    r["initial_projection"] = residuals[0]
    r["accepted_with_projection_increase"] = sum(y > x for x, y in zip(residuals, residuals[1:]))
    r["retained_nonempty_history_iterations"] = sum(x["history"] > 0 for x in points)
    r["median_edges_changed_per_accepted_update"] = statistics.median(x["changed_edges"] for x in points) if points else 0
    for a, x in zip(accepted, points):
        rows.append({"case": label, "iteration": x["accepted"], "objective": x["objective"],
                     "physical_armijo_slope": a["slope"], "objective_change": a["objective_change"],
                     "physical_projection": x["projection"], "changed_edges": x["changed_edges"],
                     "curvature_history_length": x["history"], "objective_calls": x["counts"]["objective"],
                     "gradient_calls": x["counts"]["gradient"], "line_search_trials": x["counts"]["line_search_trials"],
                     "elapsed_seconds": x["elapsed_seconds"]})
    cases[label] = r

maths = json.loads((logs/"mathematics.json").read_text())
block = json.loads((logs/"block.json").read_text())
fine = json.loads((logs/"block-fine.json").read_text())
assert block["start_sha256"] == fine["start_sha256"] == cases["short-10000"]["start_sha256"]
for item in (block, fine):
    assert np.allclose(np.diag(item["matrix"]), item["exact_256bit_diagonal"], rtol=1e-11, atol=1e-2)
assert maths["passed"]
with (out/"trajectory.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
archive_inputs = [p for p in logs.iterdir() if p.suffix in {".jsonl", ".stderr", ".stdout", ".time"}]
archive_inputs += [work/f for f in ("run-joint.sh", "run-final-joint.sh", "run-fine-block.sh", "verify-when-done.sh", "package.py", "render-report.py", "run-cost.sh", "benchmark.py", "environment.txt")]
archive_inputs += list((work/"pilot").glob("*.jsonl"))
with tarfile.open(out/"run-logs.tar.gz", "w:gz") as archive:
    for p in sorted(archive_inputs):
        blob = p.read_bytes()
        entry = tarfile.TarInfo(str(p.relative_to(work)))
        entry.size = len(blob)
        archive.addfile(entry, io.BytesIO(blob))
cost_file = logs/"cost.json"
cost = json.loads(cost_file.read_text()) if cost_file.is_file() and cost_file.stat().st_size else None
summary = {"microbenchmark": cost, "cases": cases, "mathematics": maths, "short_checkpoint_hessian_block": fine, "coarse_block_check": block,
           "stage27_passed": all(r["both_gates_passed"] for r in cases.values()),
           "raw_logs_sha256": hashlib.sha256((out/"run-logs.tar.gz").read_bytes()).hexdigest()}
(out/"results.json").write_text(json.dumps(summary, indent=2, allow_nan=False)+"\n")
for label, r in cases.items():
    print(label, r["status"], r["accepted"], r["counts"], r["independent_projection"], r["cross_path_max"])
