#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-joint-20261121
while ! (test -s "$work/.work/run/short-10000.json" && test -s "$work/.work/run/warm-10000.json" && test -s "$work/.work/run/previous-10000.json"); do
    kill -0 "$(cat "$work/.work/final.pid")" || exit 1
    sleep 5
done
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH="$work/research/mirf-muformer/dcr:/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1
python3 "$work/.work/benchmark.py" /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" "$work/.work/run/joint-pruning.so" /data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials/boundary.so /data/cc233_data/work_dir/MIRF-phylo-f81-math-attribution-20261121/.work/run/reference.so /data/cc233_data/work_dir/MIRF-phylo-boundary-conditioning-20261121/.work/run/dual.so /data/cc233_data/work_dir/MIRF-phylo-full-tree-iteration-20261121/.work/run/short-10000.npy > "$work/.work/run/cost.json"
