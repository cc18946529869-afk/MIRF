#!/usr/bin/env bash
set -euo pipefail
work=/data/cc233_data/work_dir/MIRF-phylo-direction-scale-20261121
logs="$work/.work/run"
previous=/data/cc233_data/work_dir/MIRF-phylo-line-search-scale-fix-20261121/.work/run
native=/data/cc233_data/work_dir/MIRF-phylo-numerical-diagnostics-20261121/.work/trials
cd "$work/research/mirf-muformer/dcr"
export PYTHONPATH=/data/cc233_data/work_dir/MIRF-phylo-unrooted-optimization-20261120/.work/deps/site PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OMP_THREAD_LIMIT=4 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
common=(--prep /data/cc233_data/work_dir/MIRF/research/mirf-muformer/prep --gate "$work/research/mirf-muformer/audit/phylo-36h-validation-20261120/a-gate.json" --library "$native/pruning.so" --boundary "$native/boundary.so" --archive "$previous")
run() {
    local rows=$1
    /usr/bin/time -v -o "$logs/$rows.time" python3 -m perf.check_f81_direction_scale "${common[@]}" --rows "$rows" --trace "$logs/$rows.jsonl" > "$logs/$rows.json" 2> "$logs/$rows.stderr"
    printf '%s %s complete\n' "$(date -Iseconds)" "$rows"
}
run 1000 &
pid1=$!
run 10000 &
pid2=$!
failed=0
wait "$pid1" || failed=1
wait "$pid2" || failed=1
exit "$failed"
