"""Recompute the direction-study summaries from the scalar trial ledgers."""
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import tarfile

work = Path(".work")
logs = work / "run"
out = Path("research/mirf-muformer/audit/phylo-direction-scale-20261121")
out.mkdir(parents=True, exist_ok=True)


def audit(size):
    case = json.loads((logs / f"{size}.json").read_text())
    ledger = [json.loads(line) for line in (logs / f"{size}.jsonl").read_text().splitlines()]
    directions = [row for row in ledger if row["event"] == "direction"]
    assert len(directions) == case["historical_accepted_steps_reconstructed"] + 1
    assert case["replay_verified"] and case["archived_independent_gate"]["abs_gate"] == 1e-8
    terminal = directions[-1]
    for label, summary in case["ray_summaries"].items():
        trials = [row for row in ledger if row.get("direction") == label and row["event"] == "probe"]
        assert len(trials) == summary["trials"]
        passed = []
        for trial in trials:
            q = trial["projected_inner_product"]
            rhs = terminal["objective"] + 1e-4 * q
            assert trial["armijo_rhs"] == rhs
            if trial.get("finite"):
                gain = trial["independent_objective_change"]
                assert trial["independent_armijo_gap"] == gain - 1e-4 * q
                ok = q < 0 and trial["objective"] <= rhs and gain < 0 and gain <= 1e-4 * q
                assert ok == trial["accepted_on_both_paths"]
                if ok:
                    passed.append(trial)
        assert len(passed) == summary["passes"]
        assert summary["best_probe"] == min(passed, key=lambda p: p["independent_objective_change"], default=None)
        assert summary["passing_unit_extensions"] == sum(p["alpha"] > 1 for p in passed)

    late = directions[-101:-1]
    ratios = [x["accepted_trial"]["displacement_over_unprojected_l2"] for x in late]
    case.update({"terminal_direction": terminal, "last_100_accepted_directions": {
        "accepted_alpha_counts": dict(Counter(x["accepted_alpha"] for x in late)),
        "gamma_min_max": [min(x["gamma"] for x in late), max(x["gamma"] for x in late)],
        "new_curvature_pairs_kept": sum(x["accepted_curvature_kept"] for x in late),
        "used_pair_iteration_counts": dict(Counter(x["latest_used_pair"]["accepted_iteration"]
                                                  for x in late if x["latest_used_pair"])),
        "sTy_nonpositive_count": sum(x["accepted_sTy_full"] <= 0 for x in late),
        "projection_l2_ratio_min_max": [min(ratios), max(ratios)],
        "active_constraint_count_min_max": [min(x["active_constraints"] for x in late),
                                           max(x["active_constraints"] for x in late)],
        "newly_clipped_coordinates_max": max(x["accepted_trial"]["projection_clipped_coordinates"] for x in late),
        "tangent_clip_coordinates_max": max(x["raw_outward_directions_clipped_at_zero"] for x in late),
        "free_gradient_direction_cosine_min_max": [min(x["free_gradient_direction_cosine"] for x in late),
                                                  max(x["free_gradient_direction_cosine"] for x in late)],
    }})
    return case


results = {str(n): audit(n) for n in (1000, 10000)}
with tarfile.open(out / "raw-logs.tar.gz", "w:gz") as archive:
    members = list(logs.iterdir()) + [work / name for name in ("run-all.sh", "package.py", "environment.txt")]
    for path in sorted(members):
        blob = path.read_bytes()
        info = tarfile.TarInfo(str(path.relative_to(work)))
        info.size = len(blob)
        archive.addfile(info, io.BytesIO(blob))
data = {"conclusion": "NO-GO; archived terminals and non-updating probes only",
        "cases": results, "raw_logs_sha256": hashlib.sha256((out / "raw-logs.tar.gz").read_bytes()).hexdigest()}
(out / "results.json").write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
for n, case in results.items():
    print(n, case["last_100_accepted_directions"])
    for ray, stats in case["ray_summaries"].items():
        print(ray, stats["first_zero_conflict"], stats["unit"].get("independent_objective_change"),
              stats["best_probe"], stats["passing_unit_extensions"])
